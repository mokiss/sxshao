
library(BML)

addition_test = function() 
    # Check that createBMLGrid works correctly.
{
    cat('Running addition test...\n')
    foo = createBMLGrid(100, 99, 0.4)
    r = nrow(foo)
    c = ncol(foo)
   if ( r != 100 || c != 99)
        stop('Error in addition!')
    # or stopifnot()
}

addition_test()

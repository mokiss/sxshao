movecar <-
function(m,t, no, ro){
  #if t = TRUE then move blue cars
  #if t = FALSE then move red cars
  if(t){
    #move blue cars
    #blue is a logical matrix who has the same dimension with m
    #blue indicates which one is blue cars in the grid m
    blue = m == 2
    #blank is a logical matrix who has the same dimension with m
    #blank indicates which one is empty in the grid m
    blank = m == 0
    #move blank down and add the last column ->blankt
    blankt = blank[ c(ro, 1:(ro-1) ), ]
    #if a TRUE cell in blue has the same location with that in blankt
    #then this TRUE cell (blue car) is moveable
    moveable = blankt & blue
    #then moveable cells will be empty (0)
    tmp = m
    tmp[moveable] = 0
    #then new location should be filled with 2
    tmp[ moveable[c( 2: ro, 1 ),] ] = 2
  }
  else{
    #move red
    #the logical is similar with moving blue cars
    red = m == 1
    blank = m == 0
    blankt = blank[,c(2:no, 1)]
    moveable = blankt & red
    tmp = m
    tmp[moveable] = 0
    tmp[ moveable[, c(no, 1:(no-1) )] ] = 1
    #class(tmp) = c("BML grid","matrix", paste0('move red = ', sum( moveable) ) )
  }
  return(tmp)
}

playBMLGrid <-
function(grid,name = 'moving.gif', step){
  #output a gif to show the moving process
  ani.options(interval = 0.7, loop = TRUE )
  if( is.list(grid) ){
    saveGIF({
      lapply(grid, function(i) 
        plot.BMLGrid(i) )
      ani.pause()
    }, movie.name = name)  
  }
  else{
    map = grid
    n = ncol(grid)
    c = nrow(grid)
    col = rep(c( TRUE, FALSE), step/2 + 1)[1:step]
    saveGIF({   
      plot.BMLGrid(map)
      for ( i in col){
        map = movecar(map,i, n,c)
        plot.BMLGrid(map)
      }
      ani.pause()
    }, movie.name = name )  
  }
}

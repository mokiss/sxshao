runBMLGrid <-
function(grid, step){
  map = list(start = grid)
  n = ncol(grid)
  c = nrow(grid)
  #col is a length(step) logical vector
  #each element in col indicates whether to move blue car(TRUE) or red car(FALSE)
  col = rep(c( TRUE, FALSE), step/2 + 1)[1:step]
  for ( i in 1:step){
    map[[i+1]] = movecar(map[[i]], col[i], n, c)
  }
  #map is a list containing all the matrix in moving process
  class(map) = c("BMLGrid", "List")
  return(map)
}

createBMLGrid <-
function(r, c, ncars){
  #create a matrix, blank = 0, red = 1, blue = 2
  if( r<= 0 || c <=0 || ncars <=0){
    stop(" All the arguement must be positive!")
  }
  else{
    if( sum(ncars) >= r*c){
      stop(" Number of cars must be smaller than the number of grid cells!")
    }
    else{
      map = matrix(rep(0, r*c), r , c)
      if(length(ncars) == 1){
        #ncars is the percent of cars
        if(ncars > 1){
          stop(" The percent of cars must be smaller than 1!")
        }
        else{
          #tmp contains which grid number has car
          n = as.integer(ncars*r*c)
          tmp = sample( seq(1, r*c, 1), n, replace = FALSE)
          #randomly allocate the color
          map[tmp] = sample( rep(c(1,2), n ) , n)
        }
      }
      else{
        #ncars = c( red car number, blue car number)
        tmp = sample( seq(1,c*r,1) , sum(ncars), replace = FALSE )
        map[tmp] = 2
        map[sample(tmp, ncars[1], replace = FALSE)] = 1
      }
      class(map) = c("BMLGrid", "matrix")
      return(map)
        }    
  }  
 }

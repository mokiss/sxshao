crunBMLGrid <-
function(grid, step){
  n = ncol(grid)
  c = nrow(grid)
  result = .C("crun", as.integer(grid), as.integer(step), as.integer(n), as.integer(c))[[1]]
  result = matrix(result, c , n)
  class(result) = class(grid)
  return(result)
}

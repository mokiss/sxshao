summary.BMLGrid <-
function(grid){
  if(is.list(grid)){
    #grid is a list contains all the BMLgrids
    tmp = sapply(2:length(grid), function(i) 
      compare( grid[[i-1]], grid[[i]] )  )
    tmp = data.frame(t(tmp))
  }
  else{
    redn = sum( grid == 1)
    bluen = sum( grid == 2)
    blank = prod(dim(grid)) - redn - bluen  
    tmp = data.frame( red = redn, blue = bluen, blank = blank)
  }
  return(tmp)
}

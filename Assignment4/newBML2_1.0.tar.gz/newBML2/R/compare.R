compare <-
function(grid1, grid2){
  n = ncol(grid1)
  c = nrow(grid2)
  com = grid1 != grid2
  if( sum(com) ){
    #moven is the number of cars moving from grid1 to grid2
    if(any(grid1[com] == 2 )) {
      #blue cars are moved
      if( identical( movecar(grid1, TRUE,n,c), grid2 ) ){
        moven = sum(com)/2
        col = 'blue'
        n = sum(grid1 == 2)
        blockn = n - moven
      }
      else stop("grid2 is not moved from grid1")
      
    }
    else{
      #red cars are moved
      if( identical(movecar(grid1, FALSE, n, c) ,grid2) ){
        moven = sum(com)/2
        n = sum(grid1 == 1)
        blockn = n - moven
        col = 'red'
      }
      else stop("grid2 is not moved from grid1")
    }
  }
  else{
    col = "None"
    moven = 0
    blockn = 0
    v = 0
  }
  
  result = c( color = col, move = moven, block = blockn, v = moven/n)
  
  return( result )
}

plot.BMLGrid <-
function(grid){
  image(t(grid)[,nrow(grid):1 ], col = c('white', 'red', 'blue'), main = 'Move Car') 
}

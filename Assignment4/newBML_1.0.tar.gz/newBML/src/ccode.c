#include <R.h>

void logim(int result[],int m1[], int m2[],int n);
void equalv( int result[], const int m1[], const int val, const int n);
void matrixassign(int tmp[],int m[], const int logi[], const int n, int val );
void tranblue(int tmp[], int m[], int no, int ro);
void tranblue1(int tmp[], int m[], int no, int ro);
void tranred(int tmp[], int m[], int no, int ro);
void tranred1(int tmp[], int m[], int no, int ro);

void movcar(int *m, int *t, int *no, int *ro)
{
 // m is ro*no long vector//
 int row = ro[0], col = no[0];
 int n = row*col;
 int car[n], blank[n], blankt[n], moveable[n];
 int newm[n], newm1[n],moveablet[n];
 if (*t == 1){
  //move blue cars//
  equalv(car, m, 2, n );
  equalv(blank, m, 0, n);

  tranblue(blankt, blank, col, row);
 
  logim( moveable, blankt, car, n);
 

  matrixassign(m, m, moveable, n, 0);
  tranblue1(moveablet, moveable, col, row);
  matrixassign(m, m, moveablet, n, 2);
 }
 else {
 // move red cars
  equalv(car, m, 1, n );
  equalv(blank, m, 0, n);

  tranred(blankt, blank, col, row);
 
  logim(moveable, blankt, car, n);
 

  matrixassign( m,m, moveable, n, 0);
  tranred1( moveablet, moveable, col, row);
  matrixassign( m,m, moveablet, n, 1);
 };

}




void logim(int result[],int m1[], int m2[],int n){
//m1, m2 are both arrays with length n//
 
 int i;

 for(i = 0; i<n; i++){ 
 if ( (m1[i]+m2[i]) == 2 ) 
    result[i] = 1;
 else 
    result[i] = 0;
 }
}

void equalv( int result[], const int m1[], const int val, const int n){
// val is a single value//

 int i;

 for(i = 0; i<n; i++){ 
 if ( m1[i] == val) result[i] = 1;
 else result[i] = 0;
 }
}

void matrixassign(int tmp[],int m[], const int logi[], const int n, int val ){
 int i;
 for (i = 0; i<n; i++){
 if (logi[i] == 1) tmp[i] = val; 
 else tmp[i] = m[i];
 }
}

void tranblue(int tmp[], int m[], int no, int ro){

 int i, j, n = ro*no;

 for(i = 0; i< no; i++) {
    tmp[i*ro] = m[(i+1)*ro -1];
    for(j = 1; j< ro; j++) tmp[ ro*i + j] = m[ ro*i + j -1];
 } 
}

void tranblue1(int tmp[], int m[], int no, int ro){
 int i, j, n = ro*no;

 for(i = 0; i< no; i++) {
    tmp[(i+1)*ro -1] = m[i*ro];
    for(j = 1; j< ro; j++) tmp[ ro*i + j-1] = m[ ro*i + j];
 } 
}

void tranred(int tmp[], int m[], int no, int ro){
 int i, j, n = ro*no;

 for(i = 0; i< ro; i++) {
   for(j = 1; j< no; j++) tmp[ (j-1)*ro + i] = m[ ro*j + i ];
 } 
 for(i=0; i< ro; i++) tmp[ (no-1)*ro + i] = m[i];
}

void tranred1(int tmp[], int m[], int no, int ro){
 int i, j, n = ro*no;

 for(i = 0; i< ro; i++) {

    for(j = 1; j< no; j++) tmp[ ro*j + i ] = m[ (j-1)*ro + i];
 } 
 for(i =0; i< ro; i++) tmp[i] = m[(no-1)*ro+i];

}



movecarc <-
function(m, t, no, ro){
  result =  .C("movcar", as.integer(m), 
               as.integer(t) , as.integer(no), as.integer(ro))[[1]]
  result = matrix(result, ro, no)
  class(result) = c("BMLGrid", "matrix")
  return(result)
}
